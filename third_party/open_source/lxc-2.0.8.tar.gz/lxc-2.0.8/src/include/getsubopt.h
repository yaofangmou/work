#ifndef _getsubopt_h
#define _getsubopt_h
int getsubopt (char **optionp, char *const *tokens, char **valuep);
#endif
