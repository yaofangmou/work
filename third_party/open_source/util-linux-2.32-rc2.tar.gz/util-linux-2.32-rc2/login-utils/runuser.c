
#include "su-common.h"

int main(int argc, char **argv)
{
	return su_main(argc, argv, RUNUSER_MODE);
}
